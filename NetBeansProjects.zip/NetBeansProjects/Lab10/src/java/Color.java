/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user1
 */

public class Color {

    private String name;
    private int r;
    private int g;
    private int b;
/*
    public Color(String n,int r,int g,int b)
    {
        name=n;
        this.r=r;
        this.g=g;
        this.b=b;
    }
*/
    Color(String re, int i, int i0, int i1) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        name=re;
        this.r=i;
        this.g=i0;
        this.b=i1;
    
    
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getR() {
        return r;
    }

    public void setR(int r) {
        this.r = r;
    }

    public int getG() {
        return g;
    }

    public void setG(int g) {
        this.g = g;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    public String toString()
    {
        return "Color = "+name+" r = "+r+" g = "+g+" b = "+b;
        
    }
    
}
