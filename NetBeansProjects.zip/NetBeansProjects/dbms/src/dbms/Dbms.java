/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbms;
import java.sql.*;


public class Dbms {

    public static void main(String[] args) {
        // TODO code application logic here
        try{
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        }
        catch(Exception e){
            System.out.println(e);
        }
        Connection cn=null;
        Statement stmt =null;
       try
        {
        cn=DriverManager.getConnection("jdbc:mysql://192.168.29.150:3306/ce134","ce134","ce134");
        stmt=cn.createStatement();
        stmt.executeLargeUpdate("insert into student values(135,'mayur',9.0");
      // stmt.executeUpdate("delete from student where id=135");
       
         }
    catch(Exception e)
    {
       System.out.println(e);
    }
     finally
       {
        try{   
        stmt.close();
        cn.close();
        }
        catch(Exception e){
            System.out.println(e);
        }
        }
      
     }    
}
