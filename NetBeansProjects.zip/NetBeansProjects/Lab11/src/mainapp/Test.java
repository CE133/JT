package mainapp;
import java.util.Scanner;

/**
 *
 * @author user1
 */
public class Test {

        public static void main(String ars[])
        {
            ManageEmployee me = new ManageEmployee();
            Scanner sc = new Scanner(System.in);
            boolean f = true;
            
            while(f)
            {
                System.out.println("Give your choice [ 0-add, 1-delete, 2-display ]");
                int c = sc.nextInt();
                switch(c)
                {
                    case 0:
                    {
                        System.out.println("Enter Firstname,Lastname,Salary in Sequence please !");
                        String fnm=sc.next();
                        String lnm=sc.next();
                        int s=sc.nextInt();
                        
                        me.addEmployee(fnm, lnm, s);
                        break;
                    }
                    case 1:
                    {
                        System.out.println("Enter EmployeeId to be Delete !");
                        //String fnm=sc.next();
                        //String lnm=sc.next();
                        int s=sc.nextInt();
                      
                        me.deleteEmployee(s);
                        break;
                    }
                    case 2:
                    {
                        System.out.println("Enter EmployeeId to be Show !");
                        //String fnm=sc.next();
                        //String lnm=sc.next();
                        int s=sc.nextInt();
                        me.getEmployee(s);
                        break;
                    }
                    default:
                        System.out.println("Please provide appropriate choice");
        
                }
            System.out.println("Do you want to continue (y/n) : ");
            String ch = sc.next();
            if(ch.equalsIgnoreCase("n"))
                f = false;
     
            }
        }
}
