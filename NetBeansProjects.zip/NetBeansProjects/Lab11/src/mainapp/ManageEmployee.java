/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainapp;

import hibernate.util.HibernateUtil;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import pojo.Employee;

/**
 *
 * @author user1
 */
public class ManageEmployee {
    
    private static SessionFactory factory = HibernateUtil.getSessionFactory(); 
   
    public Integer addEmployee(String fnm,String lnm,int s)
    {
      Session session = factory.openSession();
      Transaction tx = null;
      Integer employeeID = null;
      
      try {
         tx = session.beginTransaction();
         
         Employee employee = new Employee(fnm, lnm, s);//Transient
 
         employeeID = (Integer) session.save(employee);//Persistent
         tx.commit();
      } catch (HibernateException e) {
         if (tx!=null) 
             tx.rollback();
         System.out.println("Error from addEmployee() : "+e); 
      } finally {
         session.close(); 
      }
      return employeeID;
    }
    
    public void getEmployee(Integer employeeID){
      Session session = factory.openSession();
      Transaction tx = null;
      
      try {
         tx = session.beginTransaction();
         Employee employee = (Employee)session.get(Employee.class, employeeID); 
         System.out.println(employee);
         tx.commit();
      } catch (HibernateException e) {
         if (tx!=null) 
             tx.rollback();
         System.out.println("Error from updateEmployee() : "+e); 
      } finally {
         session.close(); 
      }
   }
   
     public void deleteEmployee(Integer employeeID){
      Session session = factory.openSession();
      Transaction tx = null;
      
      try {
         tx = session.beginTransaction();
         Employee employee = (Employee)session.get(Employee.class, employeeID); 
         session.delete(employee); 
         tx.commit();
      } catch (HibernateException e) {
         if (tx!=null) 
             tx.rollback();
         System.out.println("Error from deleteEmployee() : "+e); 
      } finally {
         session.close(); 
      }
   }
   
   public void closeSessionFactory()
   {
       HibernateUtil.closeSessionFactory();
   }
}
