<html>
    <head>
        <title>registration.php</title>
    </head>
    <body>
        <form method="GET" action="">
            <table border="1">
                <tr style="width:100%">
                <textarea required placeholder="Required field" rows="3" cols="50"></textarea>
                </tr>
                <tr>
                    <td style="width: 50%">Username:</td>
                    <td style="width:50%"><input type="text"></td>
                </tr>
                <tr>
                    <td style="width:50%">New Password:</td>
                    <td style="width:50%"><input type="password"></td>
                </tr>
                <tr>
                    <td style="width:50%">ReEnter New Password:</td>
                    <td style="width: 50%"><input type="password"></td>
                </tr>
                <tr>
                    <td colspan="3" style="width: 100%">
                    Male<input type="radio" name="Gender" value="MALE" />
                    Female<input type="radio" name="Gender" value="FEMALE" />
                </td>
                </tr>
                <tr>
                    <td style="width:50%">Birthdate:</td>
                    <td style="width:50%"><input type="date"></td>
                </tr>
                <tr>
                    <td style="width:50%">Interested in:</td>
                    <td style="width:50%">Training<input type="checkbox" name="Training" value="ON" />
                        Placement<input type="checkbox" name="Placement" value="ON" />
                    </td>
                </tr>
                <tr>
                    <td colspan="3" style="width:100%">
                        Achievements:
                    </td>
                </tr>
                <tr>
                    <td colspan="3" style="width: 100%"> <textarea required placeholder="" rows="3" cols="50"></textarea></td>
                </tr>
                <tr>
                    <td align="center" style="width: 33.33%">
                        <input type="submit" value="SUBMIT" name="submit" />
                    </td>
                    <td align="center" style="width: 33.33%">
                        <input type="reset" value="RESET" name="reset" />
                    </td>
                    <td align="center" style="width: 33.33%">
                        <a href="index.php">HOME
                    </td>
                    
                </tr>
                
                    
                
                   
            </table>
        </form>
    </body>
</html>