<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form method="GET" action="registration.php">
            <table border="1">
                <tr>
                    <td>Username:</td>
                    <td><input type="text" name="userid"></td>
                    
                </tr>
                <tr>
                    <td>Password:</td>
                    <td><input type="password" name="passwd"></td>
                </tr>
                <tr>
                    <td><input type="submit" value="login"></td>
                    <td><input type="reset"></td>
                </tr>
                <tr>
                    <td>
                        <a href ="registration.php">New user
                    </td>
                </tr>
    </body>
</html>
