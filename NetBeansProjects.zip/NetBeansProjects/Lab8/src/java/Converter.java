/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.beans.*;
import java.io.Serializable;

/**
 *
 * @author user1
 */
public class Converter implements Serializable {
    
    private PropertyChangeSupport propertySupport;
    String pr,pr1,pr2;Integer Res,Val1,Val2;
    public Converter() {
        propertySupport = new PropertyChangeSupport(this);
    }
    
    public void getPr(String ll)
    {
        pr=ll;
    }
    
    public void getPr1(String ll)
    {
        pr1=ll;
    }
    public void getPr2(String ll)
    {
        pr2=ll;
    }
    public void getVal1(int ll)
    {
        Val1=ll;
    }
    public void getVal2(int ll)
    {
        Val2=ll;
    }
    public int setRes()
    {
        if(pr.equals("length"))
        {
            if(pr1.equals("cm") && pr2.equals("meter"))
            {
                Res=(Val1/Val2)/100;
            }
            else if(pr1.equals("meter") && pr2.equals("cm"))
            {
                Res=(Val1*Val2)*100;
            }
        }    
        return Res;
    }
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        propertySupport.addPropertyChangeListener(listener);
    }
    
    public void removePropertyChangeListener(PropertyChangeListener listener) {
        propertySupport.removePropertyChangeListener(listener);
    }
    
}
