<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form method="post">
            <table>
                <tr>
                    <td>Name:</td><td><input type="text" name="name"></td>
                </tr>
                <tr>
                    <td>Password:</td><td><input type="password" name="pwd"></td>
                </tr>
                <tr>
                    <td>Email:</td><td><input type="text" name="email"></td>
                </tr>
                <tr>
                    <td>Mobile No:</td><td><input type="text" name="mob"></td>
                </tr
                <tr>
                    <td><input type="submit" value="Submit"></td>
                </tr>
            </table>
        </form>
        <?php
        // put your code here
        $name=$_POST['name'];
        $pwd=$_POST['pwd'];
        $email=$_POST['email'];
        $mob=$_POST['mob'];
        $validname="/^([A-Z]{1}[$-_][a-z0-9]{5,12}+)$/";
        $validpwd="/^([A-Za-z0-9]{10})/";
        if(isset($name))
        {
            if(preg_match($validname, $name))
            {
                echo'Name:'.$name ;
            }
            else{
                echo'Enter valid name from 5 to 12 characters<br>';
            }
        }
        if(isset($pwd))
        {
            if(preg_match($validpwd, $pwd))
            {
                echo'Password:'.$pwd ;
            }
            else{
                echo'Enter password of 10 characters only<br>';
            }
        }
       /* if(isset($email))
        {
            if(preg_match($validemail, $email))
            {
                echo'Email:'.$email ;
            }
            else{
                echo'Enter valid Email<br>';
            }
        }
        if(isset($pwd))
        {
            if(preg_match($validpwd, $pwd))
            {
                echo'Password:'.$pwd ;
            }
            else{
                echo'Enter password of 10 characters only<br>';
            }
        } */
        ?>
    </body>
</html>
