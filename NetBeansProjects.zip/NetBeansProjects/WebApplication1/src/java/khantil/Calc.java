package khantil;
public class Calc {
    int op1;
    int op2;
    char op;
    int result;

    public int getOp1() {
        return op1;
    }

    public int getOp2() {
        return op2;
    }

    public char getOp() {
        return op;
    }

    public int getResult() {
        switch(op){
            case '+':
                result= op1+op2;
                break;
            case '-':
                result= op1-op2;
                break;
            case '*':
                result= op1*op2;
                break;
            case '/':
                result= op1/op2;
                break;
        }
        return result;
    }
    

    public void setOp1(int op1) {
        this.op1 = op1;
    }

    public void setOp2(int op2) {
        this.op2 = op2;
    }

    public void setOp(char op) {
        this.op = op;
    }

   /* public void setResult(int result) {
        this.result = result;
    }*/
   //Object z=getServletContex().getAttribute("hits");
}
