/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package khantil;



import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;

public class ReqHits2 implements ServletRequestListener{

    @Override
    public void requestDestroyed(ServletRequestEvent sre) {
        System.out.println("Request Destroyed");
    }

    @Override
    public void requestInitialized(ServletRequestEvent sre) {
        int i = (int) sre.getServletContext().getAttribute("hits");
        i++;
        sre.getServletContext().setAttribute("hits", i);
        
        System.out.println("Request Created");
    }
    
}