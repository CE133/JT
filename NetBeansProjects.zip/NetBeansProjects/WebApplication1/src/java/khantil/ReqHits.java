/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package khantil;


import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class ReqHits implements ServletContextListener{

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        Integer hits = 0;
        sce.getServletContext().setAttribute("hits", hits);     
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}


